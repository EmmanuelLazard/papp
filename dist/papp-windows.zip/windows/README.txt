

-> 

The Windows version of Papp runs as a Linux emulated program. The 
"cygwin1.dll" library is necessary, and must be put in your WINDOWS/system 
directory of your hard disk. Beware to have a recent library. The 
library on this web site will always be up to date with Papp. If 
Papp says something is not available in the library, that is probably
because you have an old version of the "cygwin1.dll" file.  Cygwin1.dll 
is part of the Cygwin project. More information can be found on 
http://www.cygwin.com


-> 

The console-window can be resized by using the properties item
in the window menu. Change rows (48 is nice) ans columns (80 is the minimum);
don't forget to save changes for all future windows with the same name.


